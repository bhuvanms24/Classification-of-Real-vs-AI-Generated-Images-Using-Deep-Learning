"""
evaluate.py - tests the saved model on the held-out TEST images and creates all graphs.
Every number is computed from the real model - nothing is hard-coded.

Run:  python evaluate.py
"""
import os
import json
import numpy as np
import torch
import matplotlib
matplotlib.use("Agg")                      # draw graphs to files, no window needed
import matplotlib.pyplot as plt
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, confusion_matrix, roc_curve, classification_report)

import config
import data_utils
from model import load_trained_model


def _save(fig_name):
    os.makedirs(config.RESULTS_DIR, exist_ok=True)
    plt.tight_layout()
    plt.savefig(os.path.join(config.RESULTS_DIR, fig_name), dpi=150)
    plt.close()


def plot_history(history):
    """Creates the 4 training graphs (accuracy/loss for training and validation)."""
    epochs = range(1, len(history["train_loss"]) + 1)
    for key, title, ylabel, fname in [
        ("train_acc", "Training Accuracy", "Accuracy", "training_accuracy.png"),
        ("val_acc", "Validation Accuracy", "Accuracy", "validation_accuracy.png"),
        ("train_loss", "Training Loss", "Loss", "training_loss.png"),
        ("val_loss", "Validation Loss", "Loss", "validation_loss.png"),
    ]:
        plt.figure(figsize=(6, 4))
        plt.plot(epochs, history[key], marker="o")
        plt.title(title)
        plt.xlabel("Epoch")
        plt.ylabel(ylabel)
        plt.grid(alpha=0.3)
        _save(fname)


def plot_confusion_matrix(cm):
    plt.figure(figsize=(5, 4.5))
    plt.imshow(cm, cmap="Blues")
    names = ["Real", "AI-generated"]
    plt.xticks([0, 1], names)
    plt.yticks([0, 1], names)
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.title("Confusion Matrix (test set)")
    for i in range(2):
        for j in range(2):
            plt.text(j, i, f"{cm[i, j]:,}", ha="center", va="center",
                     color="white" if cm[i, j] > cm.max() / 2 else "black", fontsize=14)
    plt.colorbar()
    _save("confusion_matrix.png")


def plot_roc(labels, probs, auc):
    fpr, tpr, _ = roc_curve(labels, probs)
    plt.figure(figsize=(5, 4.5))
    plt.plot(fpr, tpr, label=f"ResNet-50 (AUC = {auc:.4f})")
    plt.plot([0, 1], [0, 1], "--", color="grey", label="Random guess")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve (test set)")
    plt.legend(loc="lower right")
    plt.grid(alpha=0.3)
    _save("roc_curve.png")


@torch.no_grad()
def get_probabilities(model, loader, device):
    """Returns (true labels, probability of 'Real') for every image in the loader."""
    all_labels, all_probs = [], []
    for images, labels in loader:
        probs = torch.sigmoid(model(images.to(device))).cpu().numpy()
        all_probs.extend(probs.tolist())
        all_labels.extend(labels.numpy().astype(int).tolist())
    return np.array(all_labels), np.array(all_probs)


def compute_metrics(labels, probs):
    """Real = positive class (as in the paper). Threshold 0.5."""
    preds = (probs >= config.THRESHOLD).astype(int)
    return {
        "accuracy": accuracy_score(labels, preds),
        "precision": precision_score(labels, preds, zero_division=0),
        "recall": recall_score(labels, preds, zero_division=0),
        "f1_score": f1_score(labels, preds, zero_division=0),
        "roc_auc": roc_auc_score(labels, probs),
    }, preds


def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")
    try:
        splits = data_utils.load_splits()
        model = load_trained_model(device)
    except (data_utils.DatasetError, FileNotFoundError) as error:
        print(f"\nPROBLEM: {error}")
        return

    loader = data_utils.make_loader(splits["test"], train=False)
    labels, probs = get_probabilities(model, loader, device)
    metrics, preds = compute_metrics(labels, probs)

    # rows/columns ordered Real, AI-generated (same layout as the paper's Table III)
    cm = confusion_matrix(labels, preds, labels=[config.LABEL_REAL, config.LABEL_AI])

    print(f"\nTest images: {len(labels)}")
    for name, value in metrics.items():
        print(f"{name:10s}: {value * 100:.2f}%" if name != "roc_auc" else f"{name:10s}: {value:.4f}")
    print("\nConfusion matrix (rows = actual, columns = predicted) [Real, AI-generated]:")
    print(cm)
    print("\n" + classification_report(labels, preds, target_names=["AI-generated", "Real"], digits=4))

    plot_confusion_matrix(cm)
    plot_roc(labels, probs, metrics["roc_auc"])
    if os.path.exists(config.HISTORY_PATH):
        with open(config.HISTORY_PATH) as f:
            plot_history(json.load(f))

    metrics_out = {k: float(v) for k, v in metrics.items()}
    metrics_out["confusion_matrix_real_ai"] = cm.tolist()
    metrics_out["test_images"] = int(len(labels))
    with open(config.METRICS_PATH, "w") as f:
        json.dump(metrics_out, f, indent=2)
    print(f"Graphs and metrics.json saved in: {config.RESULTS_DIR}")


if __name__ == "__main__":
    main()
