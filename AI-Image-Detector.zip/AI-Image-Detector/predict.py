r"""
predict.py - loads the trained model and predicts ONE image.
Used by app.py (website). You can also test from the terminal:
    python predict.py path\to\image.jpg
"""
import sys
import torch
from PIL import Image

import config
from data_utils import get_eval_transform
from model import load_trained_model

_device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
_model = None
_transform = get_eval_transform()          # SAME preprocessing as validation/testing


def get_model():
    """Loads the model the first time it is needed, then re-uses it."""
    global _model
    if _model is None:
        _model = load_trained_model(_device)
    return _model


def predict_image(image):
    """image: a PIL image. Returns a dictionary with label, confidence and both probabilities."""
    model = get_model()
    tensor = _transform(image.convert("RGB")).unsqueeze(0).to(_device)
    with torch.no_grad():
        prob_real = torch.sigmoid(model(tensor)).item()
    prob_ai = 1.0 - prob_real
    is_real = prob_real >= config.THRESHOLD
    return {
        "label": "REAL IMAGE" if is_real else "AI-GENERATED IMAGE",
        "is_real": bool(is_real),
        "confidence": (prob_real if is_real else prob_ai) * 100,
        "prob_real": prob_real * 100,
        "prob_ai": prob_ai * 100,
    }


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python predict.py path\\to\\image.jpg")
        sys.exit(1)
    try:
        result = predict_image(Image.open(sys.argv[1]))
        print(f"Model prediction: {result['label']}")
        print(f"Model confidence: {result['confidence']:.2f}%")
    except FileNotFoundError as error:
        print(error)
    except Exception:
        print("Could not read that file as an image.")
