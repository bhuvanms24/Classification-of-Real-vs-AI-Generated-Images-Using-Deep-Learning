"""
config.py - ALL settings live here, so you only change numbers in ONE place.
Values marked [PAPER] come straight from the research paper.
"""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ---------- Folders ----------
DATASET_DIR = os.path.join(BASE_DIR, "dataset")
REAL_DIR = os.path.join(DATASET_DIR, "real")
AI_DIR = os.path.join(DATASET_DIR, "ai_generated")
MODELS_DIR = os.path.join(BASE_DIR, "models")
RESULTS_DIR = os.path.join(BASE_DIR, "results")

MODEL_PATH = os.path.join(MODELS_DIR, "resnet50_ai_detector.pth")
SPLIT_PATH = os.path.join(MODELS_DIR, "dataset_split.json")      # remembers which image is in train/val/test
HISTORY_PATH = os.path.join(RESULTS_DIR, "training_history.json")
METRICS_PATH = os.path.join(RESULTS_DIR, "metrics.json")

# ---------- Classes ----------
# [PAPER] Class 0 = AI-generated, Class 1 = Real (Real is the "positive" class)
CLASS_NAMES = ["AI-generated", "Real"]
LABEL_AI = 0
LABEL_REAL = 1
THRESHOLD = 0.5            # [PAPER] probability >= 0.5 -> Real, otherwise AI-generated

# ---------- Images ----------
IMAGE_SIZE = 224                                   # [PAPER]
IMAGENET_MEAN = [0.485, 0.456, 0.406]              # [PAPER] ImageNet normalisation
IMAGENET_STD = [0.229, 0.224, 0.225]
ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}

# ---------- Dataset split ----------
TRAIN_RATIO = 0.70                                 # [PAPER]
VAL_RATIO = 0.15                                   # [PAPER]
TEST_RATIO = 0.15                                  # [PAPER]
SEED = 42
MIN_IMAGES_PER_CLASS = 20                          # below this the split is meaningless
BALANCE_CLASSES = True                             # [PAPER] balanced classes (trims the bigger class)

# ---------- Training ----------
BATCH_SIZE = 32                                    # [PAPER]
MAX_EPOCHS = 30                                    # [PAPER] (stage 1 + stage 2 together)
STAGE1_EPOCHS = 5                                  # [ASSUMPTION] paper does not say how long stage 1 lasts
LR_HEAD = 1e-4                                     # [PAPER]
LR_FINETUNE = 1e-5                                 # [PAPER]
DROPOUT = 0.5                                      # [PAPER]
EARLY_STOP_PATIENCE = 5                            # [PAPER]
SCHEDULER_FACTOR = 0.5                             # [PAPER]
SCHEDULER_PATIENCE = 3                             # [PAPER]
NUM_WORKERS = 2                                    # set to 0 if you get DataLoader errors on Windows

# ---------- Website ----------
MAX_UPLOAD_MB = 10
