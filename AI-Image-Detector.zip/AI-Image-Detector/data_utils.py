"""
data_utils.py - everything about DATA: finding images, removing bad/duplicate
files, splitting 70/15/15, image transforms (augmentation) and DataLoaders.
Used by train.py, evaluate.py and predict.py (so preprocessing is identical everywhere).
"""
import os
import json
import random
import hashlib

from PIL import Image
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset, DataLoader
import torch
from torchvision import transforms

import config


class DatasetError(Exception):
    """Raised with a friendly message when the dataset folders are wrong."""


# ---------------------------------------------------------------- transforms
def get_train_transform():
    """Augmentation used ONLY for training images. [PAPER] flip, rotation, brightness/contrast, crop."""
    resize_to = int(config.IMAGE_SIZE * 256 / 224)             # 256, then random-crop 224
    return transforms.Compose([
        transforms.Resize((resize_to, resize_to)),
        transforms.RandomCrop(config.IMAGE_SIZE),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.RandomRotation(15),
        transforms.ColorJitter(brightness=0.2, contrast=0.2),
        transforms.ToTensor(),
        transforms.Normalize(config.IMAGENET_MEAN, config.IMAGENET_STD),
    ])


def get_eval_transform():
    """NO augmentation. Used for validation, testing AND the website prediction."""
    return transforms.Compose([
        transforms.Resize((config.IMAGE_SIZE, config.IMAGE_SIZE)),
        transforms.ToTensor(),
        transforms.Normalize(config.IMAGENET_MEAN, config.IMAGENET_STD),
    ])


# ------------------------------------------------------------ finding images
def _is_valid_image(path):
    try:
        with Image.open(path) as img:
            img.verify()
        return True
    except Exception:
        return False


def _file_hash(path):
    with open(path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()


def collect_clean_images(folder, class_name, limit=None):
    """Return a list of valid, non-duplicate image paths from a folder (searches sub-folders too)."""
    if not os.path.isdir(folder):
        raise DatasetError(
            f"Folder not found: {folder}\n"
            f"Create it and put your '{class_name}' images inside."
        )
    all_paths = []
    for root, _, files in os.walk(folder):
        for name in files:
            if os.path.splitext(name)[1].lower() in config.ALLOWED_EXTENSIONS:
                all_paths.append(os.path.join(root, name))
    if not all_paths:
        raise DatasetError(
            f"No images found in {folder}\n"
            f"Supported formats: {', '.join(sorted(config.ALLOWED_EXTENSIONS))}"
        )

    random.Random(config.SEED).shuffle(all_paths)              # so 'limit' picks a random sample
    clean, seen, bad, dup = [], set(), 0, 0
    for i, path in enumerate(all_paths, start=1):
        if limit and len(clean) >= limit:
            break
        if not _is_valid_image(path):
            bad += 1
            continue
        h = _file_hash(path)
        if h in seen:
            dup += 1
            continue
        seen.add(h)
        clean.append(path)
        if i % 5000 == 0:
            print(f"   checked {i}/{len(all_paths)} files in '{class_name}'...")
    print(f"[{class_name}] usable: {len(clean)} | corrupted skipped: {bad} | duplicates skipped: {dup}")
    return clean


def _rel(path):
    return os.path.relpath(path, config.BASE_DIR).replace("\\", "/")


# --------------------------------------------------------------------- split
def prepare_splits(limit_per_class=None):
    """Find images, clean them, split 70/15/15 (stratified), save split to a JSON file."""
    real = collect_clean_images(config.REAL_DIR, "real", limit_per_class)
    ai = collect_clean_images(config.AI_DIR, "ai_generated", limit_per_class)

    if min(len(real), len(ai)) < config.MIN_IMAGES_PER_CLASS:
        raise DatasetError(
            f"Need at least {config.MIN_IMAGES_PER_CLASS} usable images in EACH folder "
            f"(found real={len(real)}, ai_generated={len(ai)}). Add more images."
        )
    if config.BALANCE_CLASSES and len(real) != len(ai):
        n = min(len(real), len(ai))
        print(f"Classes are unequal, using {n} images per class to keep them balanced (as in the paper).")
        real, ai = real[:n], ai[:n]

    paths = real + ai
    labels = [config.LABEL_REAL] * len(real) + [config.LABEL_AI] * len(ai)

    # 70% train, 30% temporary -> temporary split half/half into 15% val and 15% test
    train_p, temp_p, train_l, temp_l = train_test_split(
        paths, labels, test_size=config.VAL_RATIO + config.TEST_RATIO,
        stratify=labels, random_state=config.SEED)
    val_p, test_p, val_l, test_l = train_test_split(
        temp_p, temp_l, test_size=0.5, stratify=temp_l, random_state=config.SEED)

    splits = {
        "train": [[_rel(p), l] for p, l in zip(train_p, train_l)],
        "val": [[_rel(p), l] for p, l in zip(val_p, val_l)],
        "test": [[_rel(p), l] for p, l in zip(test_p, test_l)],
    }
    os.makedirs(config.MODELS_DIR, exist_ok=True)
    with open(config.SPLIT_PATH, "w") as f:
        json.dump(splits, f)

    print("\nDataset split (stratified):")
    for name, items in splits.items():
        n_real = sum(1 for _, l in items if l == config.LABEL_REAL)
        print(f"  {name:5s}: {len(items):6d} images  (real={n_real}, ai={len(items) - n_real})")
    return splits


def load_splits():
    """Load the split that train.py saved (evaluate.py must test on the SAME test images)."""
    if not os.path.exists(config.SPLIT_PATH):
        raise DatasetError("dataset_split.json not found. Run train.py first.")
    with open(config.SPLIT_PATH) as f:
        return json.load(f)


# ------------------------------------------------------------ Dataset/Loader
class ImageListDataset(Dataset):
    """Reads (path, label) pairs, opens each image, converts to RGB and applies the transform."""

    def __init__(self, items, transform):
        self.items = items
        self.transform = transform

    def __len__(self):
        return len(self.items)

    def __getitem__(self, index):
        rel_path, label = self.items[index]
        image = Image.open(os.path.join(config.BASE_DIR, rel_path)).convert("RGB")
        return self.transform(image), torch.tensor(float(label))


def make_loader(items, train, batch_size=None):
    dataset = ImageListDataset(items, get_train_transform() if train else get_eval_transform())
    return DataLoader(dataset, batch_size=batch_size or config.BATCH_SIZE, shuffle=train,
                      num_workers=config.NUM_WORKERS, pin_memory=torch.cuda.is_available())
