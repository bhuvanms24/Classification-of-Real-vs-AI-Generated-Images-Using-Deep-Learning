r"""
organize_dataset.py - copies images from any downloaded folders into
dataset/real and dataset/ai_generated (renaming to avoid name clashes).

Example (Command Prompt / VS Code terminal):
    python organize_dataset.py --real "C:\Downloads\cifake\train\REAL" --ai "C:\Downloads\cifake\train\FAKE" --limit 5000
You can run it several times with different source folders to grow the dataset.
"""
import os
import shutil
import argparse
import config


def copy_images(source, destination, prefix, limit):
    if not os.path.isdir(source):
        print(f"Source folder not found: {source}")
        return 0
    os.makedirs(destination, exist_ok=True)
    copied = 0
    for root, _, files in os.walk(source):
        for name in sorted(files):
            if os.path.splitext(name)[1].lower() not in config.ALLOWED_EXTENSIONS:
                continue
            if limit and copied >= limit:
                return copied
            shutil.copy2(os.path.join(root, name), os.path.join(destination, f"{prefix}_{copied}_{name}"))
            copied += 1
    return copied


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--real", required=True, help="folder containing REAL photos")
    parser.add_argument("--ai", required=True, help="folder containing AI-generated images")
    parser.add_argument("--limit", type=int, default=None, help="max images to copy per class")
    parser.add_argument("--tag", default="src1", help="short name for this source (avoids file-name clashes)")
    args = parser.parse_args()
    n_real = copy_images(args.real, config.REAL_DIR, args.tag + "_real", args.limit)
    n_ai = copy_images(args.ai, config.AI_DIR, args.tag + "_ai", args.limit)
    print(f"Copied {n_real} real images and {n_ai} AI images into the dataset folder.")


if __name__ == "__main__":
    main()
