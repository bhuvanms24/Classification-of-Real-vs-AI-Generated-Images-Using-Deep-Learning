"""
compare_models.py - OPTIONAL. Trains the comparison models from the paper on the SAME
split (dataset_split.json made by train.py) and writes results/comparison.csv.
Run train.py + evaluate.py FIRST. VGG-16 and ViT-B/16 are heavy: use a GPU / Colab.

Run:  python compare_models.py --models baseline_cnn efficientnet_b0 --max-epochs 10
Practical protocol for these models: pretrained ones are fully fine-tuned
(final layer lr 1e-4, everything else lr 1e-5); baseline CNN is trained from scratch (lr 1e-4).
"""
import os
import csv
import json
import argparse
import torch
import torch.nn as nn

import config
import data_utils
from model import build_comparison_model
from train import fit_stage
from evaluate import get_probabilities, compute_metrics


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--models", nargs="+", default=["baseline_cnn", "vgg16", "efficientnet_b0", "vit_b_16"])
    parser.add_argument("--max-epochs", type=int, default=config.MAX_EPOCHS)
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")
    try:
        splits = data_utils.load_splits()
    except data_utils.DatasetError as error:
        print(error)
        return
    train_loader = data_utils.make_loader(splits["train"], train=True)
    val_loader = data_utils.make_loader(splits["val"], train=False)
    test_loader = data_utils.make_loader(splits["test"], train=False)

    rows = []
    if os.path.exists(config.METRICS_PATH):          # ResNet-50 row from the main run
        with open(config.METRICS_PATH) as f:
            m = json.load(f)
        rows.append(["resnet50 (main run)", m["accuracy"], m["precision"], m["recall"], m["f1_score"], m["roc_auc"]])

    for name in args.models:
        print(f"\n===== {name} =====")
        model, new_layer, pretrained = build_comparison_model(name)
        model.to(device)
        new_ids = {id(p) for p in new_layer.parameters()}
        others = [p for p in model.parameters() if id(p) not in new_ids]
        groups = [{"params": list(new_layer.parameters()), "lr": config.LR_HEAD},
                  {"params": others, "lr": config.LR_FINETUNE if pretrained else config.LR_HEAD}]
        optimizer = torch.optim.Adam(groups)
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, factor=config.SCHEDULER_FACTOR, patience=config.SCHEDULER_PATIENCE)
        history = {"train_loss": [], "val_loss": [], "train_acc": [], "val_acc": []}
        best_state = {}
        best = {"val_loss": float("inf"), "epoch": 0}

        def keep_best():
            best_state["weights"] = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

        fit_stage(model, (train_loader, val_loader), optimizer, scheduler, nn.BCEWithLogitsLoss(), device,
                  args.max_epochs, history, best, lambda m: m.train(), name, True,
                  config.EARLY_STOP_PATIENCE, keep_best)
        model.load_state_dict(best_state["weights"])
        model.eval()
        labels, probs = get_probabilities(model, test_loader, device)
        metrics, _ = compute_metrics(labels, probs)
        rows.append([name, metrics["accuracy"], metrics["precision"], metrics["recall"],
                     metrics["f1_score"], metrics["roc_auc"]])
        del model, optimizer
        torch.cuda.empty_cache()

    out_path = os.path.join(config.RESULTS_DIR, "comparison.csv")
    with open(out_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["model", "accuracy", "precision", "recall", "f1", "roc_auc"])
        writer.writerows(rows)
    print(f"\nSaved: {out_path}")
    for r in rows:
        print(f"{r[0]:22s} acc={r[1]:.4f} prec={r[2]:.4f} rec={r[3]:.4f} f1={r[4]:.4f} auc={r[5]:.4f}")


if __name__ == "__main__":
    main()
