# Classification of Real vs AI-Generated Images Using Deep Learning
ResNet-50 + Transfer Learning + PyTorch + Flask + HTML/CSS/JavaScript

> **Honest status:** the code was written and syntax-checked, but it has **not been trained** here (no dataset and no GPU were available). All results must come from YOUR run. Nothing in this project is copied from the paper's result tables.

---
## 1. Project structure (what each file does)

```
AI-Image-Detector/
├── config.py            all settings (image size, learning rates, paths...)
├── data_utils.py        NEW (extra file): finds images, removes corrupted/duplicate files, 70/15/15 split, augmentation, DataLoaders
├── model.py             ResNet-50 + custom head, freezing/unfreezing, save/load
├── train.py             two-stage training, early stopping, saves best model + graphs
├── evaluate.py          test-set metrics + confusion matrix + ROC + graphs
├── predict.py           predicts one image (used by the website; also usable from terminal)
├── app.py               Flask back end
├── organize_dataset.py  NEW (helper): copies downloaded images into dataset/real and dataset/ai_generated
├── compare_models.py    OPTIONAL: baseline CNN, VGG-16, EfficientNet-B0, ViT-B/16
├── colab_training.ipynb NEW: Google Colab notebook
├── requirements.txt
├── dataset/real/  dataset/ai_generated/
├── models/              resnet50_ai_detector.pth appears here after training
├── results/             graphs + metrics.json appear here after training/evaluation
├── static/css/style.css   static/js/script.js   templates/index.html
```
**Changes from your suggested structure:** added `data_utils.py` (so training, evaluation and the website share identical preprocessing), `organize_dataset.py`, `compare_models.py` and the notebook. The `uploads/` folder is not needed: the website reads the uploaded image directly from memory and never stores user files (safer and simpler).

---
## 2. Paper specification vs practical implementation

| Item | Paper specification | Practical implementation |
|---|---|---|
| Dataset | 120,000 images (60k/60k) | Any size you provide; auto 70/15/15 stratified split; balanced by trimming the larger class |
| Backbone | ResNet-50, ImageNet | Same (`torchvision` weights `IMAGENET1K_V1`) |
| Head | GAP → 2048→512 → ReLU → Dropout 0.5 → 1 → Sigmoid | Same. The network outputs a raw score; sigmoid is applied at prediction time |
| Loss | Sigmoid + Binary Cross-Entropy | `BCEWithLogitsLoss` = the same maths in one numerically stable step |
| Optimizer / LR | Adam; 1e-4 head; 1e-5 fine-tuned block | Same. Stage 2 uses two learning-rate groups |
| Stage 1 length | **Not specified** | 5 epochs (`STAGE1_EPOCHS` in `config.py`) - my assumption |
| Epochs / batch | max 30 / 32 | Same (30 = stage 1 + stage 2 together) |
| Early stopping | patience 5 | On validation loss, during stage 2 |
| Scheduler | ReduceLROnPlateau, factor 0.5, patience 3 | Same, stage 2 |
| Augmentation | flip, ±15° rotation, brightness/contrast, random crop | Resize 256 → random crop 224, flip, rotation 15°, ColorJitter(0.2, 0.2) - exact strengths not in paper |
| Threshold | ≥ 0.5 → Real | Same; Class 0 = AI, Class 1 = Real |
| Duplicate/corrupt removal | Yes | Yes (MD5 hash of file contents) |
| Hardware | T4 GPU | Automatic CUDA/CPU detection |
| Comparison models | 5 models | Optional script; ResNet-50 row comes from the main run |

### Inconsistencies I found in the paper (worth fixing before submission)
* Abstract says recall **97.1%**, Table IV and the conclusion say **96.53% / 96.5%**. Table III's confusion matrix gives recall = 8739 / 9000 = **97.1%** and precision = 8739 / 9054 = **96.52%**, so Table IV's recall does not match Table III.
* F1 of 96.82% is not consistent with precision 96.52% and recall 96.53% (that would give ≈ 96.5%). With the matrix values (97.1% and 96.52%) F1 ≈ 96.8%.
* The comparison table (Table V) and training details (e.g. stopping at epoch 22) will not automatically match what you get. **Replace them with your own measured results.**
* CIFAKE images are only 32×32; the paper describes a mixed 120k dataset from several sources. If you cannot get exactly that dataset, say so in your report.

---
## 3. Setup on Windows (copy-paste)

**3.1 Install Python** - Download Python 3.11 from python.org → run installer → **tick "Add python.exe to PATH"** → Install. Check in *Command Prompt*:
```
python --version
```
**3.2 Create the folder & open it** - Put the `AI-Image-Detector` folder somewhere simple, e.g. `C:\Projects\AI-Image-Detector`. Install VS Code (code.visualstudio.com) → File → Open Folder → choose it → Terminal → New Terminal.

**3.3 Virtual environment** (VS Code terminal). If PowerShell blocks activation, first run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`.
```
python -m venv venv
venv\Scripts\activate
```
You should see `(venv)` at the start of the line. Do this activation every time you open a new terminal.

**3.4 Install libraries** (VS Code terminal, venv active; needs internet, takes several minutes)
```
python -m pip install --upgrade pip
pip install -r requirements.txt
```
If you have an NVIDIA GPU and want GPU training, get the exact command from pytorch.org → "Get Started" (choose Windows / Pip / CUDA) and run it instead of installing torch from requirements.

**3.5 Check PyTorch and GPU**
```
python -c "import torch; print(torch.__version__); print('CUDA available:', torch.cuda.is_available())"
```
`False` is fine: the code uses the CPU automatically (slow). Use Colab for faster training.

---
## 4. Dataset preparation
Layout the code expects:
```
dataset/real/            <- real photographs (jpg, png, webp, bmp)
dataset/ai_generated/    <- AI-generated images
```
Start with about 1,000-5,000 images per class. The code cleans the data, balances classes and splits 70/15/15 automatically.

**Public datasets (search these exact names; check each dataset's own page for licence and download instructions - I am not providing links I cannot verify):**
* **CIFAKE** (Bird & Lotfi, your reference [9]) - on Kaggle. Contains `REAL` and `FAKE` folders (Stable Diffusion images). Images are 32×32, so they are upscaled to 224 and detection quality is limited, but it is small and easy for a first run. REAL → `dataset/real`, FAKE → `dataset/ai_generated`.
* **ArtiFact** (Rahman et al., your reference [11], arXiv:2302.11970) - large, many generators; find the download instructions in the paper/its repository. Real-photo sub-folders → `real`, generator folders → `ai_generated`.
* Kaggle also hosts real-vs-StyleGAN face datasets; search "real and fake faces" and read what is in them.

**Copy images with the helper** (Command Prompt/VS Code terminal, venv active):
```
python organize_dataset.py --real "C:\Downloads\cifake\train\REAL" --ai "C:\Downloads\cifake\train\FAKE" --limit 5000 --tag cifake
```
Run again with another `--tag` and other folders to add more data. (You can also just copy files by hand.)

**Growing to a large dataset later:** add more images to the two folders and re-run `python train.py`. Nothing else changes. For 100k+ images, use Colab/GPU (copy the dataset into Colab's local disk, not straight from Drive, for speed).

---
## 5. Train, evaluate, run the website
**Train** (VS Code terminal)
```
python train.py
```
Quick test first (few minutes on CPU): `python train.py --limit-per-class 200 --max-epochs 6 --stage1-epochs 2`

Expected output: `Device: cuda` or `Device: cpu`, dataset counts, per-epoch lines for STAGE 1 and STAGE 2, "Early stopping..." possibly, and files `models/resnet50_ai_detector.pth`, `models/dataset_split.json`, `results/training_history.json` and the 4 training graphs. First run downloads ResNet-50 weights (~100 MB).

**Two-stage transfer learning explained:** Stage 1 freezes the ImageNet-trained ResNet-50 so only the new head (which starts random) learns. Stage 2 unfreezes the last residual block (`layer4`) and trains it gently (lr 1e-5) so its features adapt to real-vs-AI clues, while the head continues at 1e-4.

**Evaluate**
```
python evaluate.py
```
Prints accuracy, precision, recall, F1, ROC-AUC, confusion matrix; saves `results/confusion_matrix.png`, `roc_curve.png`, the 4 training graphs and `metrics.json`. It tests on the same held-out test images chosen by `train.py`. (Real = positive class.)

**Command-line single prediction:** `python predict.py "C:\path\to\image.jpg"`

**Start the website**
```
python app.py
```
Open **http://127.0.0.1:5000** in Chrome. Upload (or drag) an image → **Analyze image** → see "Model prediction", "Model confidence" and the confidence bar. **Analyze another image** resets. Stop the server with `Ctrl + C`.

---
## 6. Google Colab training
1. Zip your project folder as `AI-Image-Detector.zip` and your dataset as `dataset.zip` (containing `real/` and `ai_generated/`). Upload both to *My Drive* on drive.google.com.
2. Open colab.research.google.com → File → Upload notebook → `colab_training.ipynb`.
3. Runtime → Change runtime type → **T4 GPU**.
4. Run cells top to bottom (mount Drive, unpack, train, evaluate).
5. The last cells download `resnet50_ai_detector.pth` (and `results.zip`). Put the `.pth` file into your local `AI-Image-Detector\models\` folder (the website does not need `dataset_split.json`). Then run `python app.py`.
Colab sessions expire: download the model before closing.

---
## 7. Testing checklist
* Upload a JPG of a real photo (e.g. from your phone) → a prediction appears.
* Upload an AI image (e.g. one you generated with a public image generator) → prediction appears.
* Try to upload a `.txt` file → "Unsupported file type". Rename a text file to `x.jpg` and upload it → "could not be read as an image". With nothing chosen, the Analyze button is disabled.
* Delete/rename the `.pth` file and start `app.py` → red "Model not ready" banner instead of a crash.
* Empty `dataset/` folders → `train.py` prints "DATASET PROBLEM" with what to fix.
Wrong predictions are normal; always check with images from different sources.

---
## 8. Actual Experimental Results  (fill in after YOUR run)
Copy the numbers printed by `python evaluate.py` (or `results/metrics.json`).

| Item | Value |
|---|---|
| Dataset used (name, images per class) | |
| Train / Val / Test images | |
| Device (GPU model or CPU) | |
| Epochs trained / best epoch | |
| Accuracy | |
| Precision | |
| Recall | |
| F1-score | |
| ROC-AUC | |
| Confusion matrix (Real/AI) | |

**If your numbers differ from the paper's (96.8% etc.) that is normal**: different dataset, size, image resolution, random seed and hardware all change results. Report YOUR numbers honestly and mention the paper's values only as reported by the paper.

---
## 9. Optional: comparison models
Only after ResNet-50 works: `python compare_models.py --models baseline_cnn efficientnet_b0 --max-epochs 10` (add `vgg16`, `vit_b_16` on a GPU). Uses the same split and metrics; writes `results/comparison.csv`. Protocol differences: pretrained comparison models are fully fine-tuned (new layer 1e-4, rest 1e-5); the baseline CNN is trained from scratch.
Not included (kept simple): prediction history, Grad-CAM, an About page.

---
## 10. Demonstration plan (5-10 minutes)
1. **Problem (1 min):** AI images look real; misinformation and forensics need automatic checking.
2. **Dataset (1 min):** open `dataset/`; show real and AI folders; say "70% train, 15% validation, 15% test, balanced."
3. **ResNet-50 (1.5 min):** pretrained on ImageNet; skip connections; we replaced the last layer with our head; two-stage transfer learning.
4. **Training (1 min):** show the terminal output of `train.py` (or the Colab screenshot): loss falling, early stopping, best model saved.
5. **Evaluation (1.5 min):** show `results/` graphs and metrics; explain confusion matrix and ROC.
6. **Website (3 min):** `python app.py`; upload a real photo → show prediction; upload an AI image → show prediction; explain confidence.
7. **Limitations (1 min):** new generators, compression, resizing, not proof, no explanation of "why" (Grad-CAM future work).

**What to say about each component:** `data_utils.py` - "prepares and cleans the images and splits them"; `model.py` - "builds ResNet-50 with our custom head"; `train.py` - "teaches the model in two stages"; `evaluate.py` - "measures it on images it never saw"; `predict.py` + `app.py` - "load the saved model and answer web requests"; `script.js` - "sends the image to Flask and shows the result".
Tip: test 5-6 images in advance and prepare some the model gets right; if it gets one wrong, explain it honestly as a limitation.

---
## 11. Viva questions and answers
1. **What is AI-generated image detection?** Automatically deciding whether an image was captured by a camera or created by an AI model.
2. **Why this problem?** AI images can spread fake news and fraud; people can no longer reliably tell by eye.
3. **What is a CNN?** A neural network for images. It slides small filters over the image to learn edges, textures and then object parts.
4. **What is ResNet?** A CNN with "skip connections" that add a layer's input to its output, so very deep networks can be trained without the gradient vanishing.
5. **Why ResNet-50?** 50 layers gives strong features with reasonable size/speed, and pretrained versions are readily available.
6. **What is transfer learning?** Re-using a network trained on a big task (ImageNet) for a new task, so we need less data and time.
7. **What is ImageNet?** A dataset of over a million labelled images in 1000 classes used to pre-train vision models.
8. **Why 224 × 224?** ResNet-50 was pre-trained with that size; it keeps compute manageable.
9. **What is data augmentation?** Randomly flipping, rotating, cropping and changing brightness of training images to create variety and reduce overfitting. Not applied at test time.
10. **What is overfitting?** Memorising the training data, so training accuracy is high but new-image accuracy is low. We watch validation loss to detect it.
11. **What is dropout?** Randomly switching off 50% of neurons during training so the network does not depend on any single neuron.
12. **Why Adam?** It adapts the learning rate per parameter and works well with little tuning.
13. **What is binary cross-entropy?** The loss for two-class problems; it penalises confident wrong predictions heavily. (We use `BCEWithLogitsLoss`, which is sigmoid + BCE combined.)
14. **What is sigmoid?** A function that squashes any number into 0-1, so the output can be read as a probability.
15. **What is precision?** Of images predicted Real, the fraction that really are Real: TP / (TP + FP).
16. **What is recall?** Of all Real images, the fraction the model found: TP / (TP + FN).
17. **What is F1-score?** The harmonic mean of precision and recall; one number balancing both.
18. **What is ROC-AUC?** Area under the curve of true-positive rate versus false-positive rate over all thresholds. 1.0 is perfect, 0.5 is random guessing.
19. **What is a confusion matrix?** A 2×2 table of actual versus predicted classes showing correct predictions and the two kinds of mistakes.
20. **What are the limitations?** Depends on training data; may fail on new generators, screenshots or heavily compressed images; gives a probability, not proof; does not explain its decision.
21. **What if a new AI generator makes different images?** Accuracy can drop because artefacts differ. The fix is adding images from the new generator and retraining.
22. **Why can the model make mistakes?** Some AI images are extremely realistic, some real photos are edited or low quality, and the model only learned patterns from its training set.
23. **Why two-stage training?** The new head is random; training it first prevents its large early errors from damaging the pretrained features. Then we fine-tune the last block gently.
24. **Why separate validation and test sets?** Validation guides training (early stopping); the test set is used once at the end for an unbiased score.
25. **Why do you say "model confidence" and not "accuracy"?** Confidence is the model's own probability; a model can be confidently wrong.

---
## 12. Common errors and fixes
| Message | Fix |
|---|---|
| `python is not recognized` | Reinstall Python and tick "Add to PATH"; reopen VS Code |
| `venv\Scripts\activate` blocked in PowerShell | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, or use Command Prompt |
| `No module named torch` (or flask, sklearn) | venv not active or requirements not installed: activate, then `pip install -r requirements.txt` |
| `DATASET PROBLEM: Folder not found / No images found` | Put images in `dataset\real` and `dataset\ai_generated` |
| Training is extremely slow | CPU only; use `--limit-per-class`, or Colab GPU |
| `CUDA out of memory` | `python train.py --batch-size 16` |
| Errors mentioning DataLoader/workers on Windows | set `NUM_WORKERS = 0` in `config.py` |
| Cannot download ResNet weights | Needs internet on first `train.py` run |
| Website shows "Model not ready" | Run `train.py`, or place the `.pth` in `models\` and restart `app.py` |
| Port 5000 already in use | Close the other server, or change `port=5000` in `app.py` |
| "Cannot reach the server" in browser | `python app.py` was stopped; start it again |
