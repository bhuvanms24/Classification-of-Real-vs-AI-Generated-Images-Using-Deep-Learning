"""
app.py - the Flask website/back end.
Run:  python app.py      then open  http://127.0.0.1:5000
"""
import os
from flask import Flask, render_template, request, jsonify
from PIL import Image

import config
import predict

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = config.MAX_UPLOAD_MB * 1024 * 1024

# Try to load the model at start-up so a missing model is reported clearly.
MODEL_ERROR = None
try:
    predict.get_model()
    print("Model loaded successfully.")
except FileNotFoundError as error:
    MODEL_ERROR = str(error)
    print("WARNING:", MODEL_ERROR)
except Exception as error:
    MODEL_ERROR = "The model file could not be loaded. Train the model again with train.py."
    print("WARNING:", error)


def error_response(message, status):
    return jsonify({"success": False, "error": message}), status


@app.route("/")
def home():
    return render_template("index.html", model_ready=MODEL_ERROR is None, model_error=MODEL_ERROR,
                           max_mb=config.MAX_UPLOAD_MB)


@app.route("/predict", methods=["POST"])
def predict_route():
    if MODEL_ERROR:
        return error_response(MODEL_ERROR, 503)

    file = request.files.get("image")
    if file is None or file.filename == "":
        return error_response("No image uploaded. Please choose an image first.", 400)

    extension = os.path.splitext(file.filename)[1].lower()
    if extension not in config.ALLOWED_EXTENSIONS:
        allowed = ", ".join(sorted(config.ALLOWED_EXTENSIONS))
        return error_response(f"Unsupported file type '{extension}'. Please upload: {allowed}", 400)

    try:
        image = Image.open(file.stream)
        image.load()                                   # forces full read -> detects corrupted files
    except Exception:
        return error_response("This file could not be read as an image. It may be corrupted.", 400)

    try:
        result = predict.predict_image(image)
    except Exception:
        app.logger.exception("Prediction failed")
        return error_response("Something went wrong while analysing the image.", 500)

    result["success"] = True
    result["width"], result["height"] = image.size
    result["format"] = image.format or extension.strip(".").upper()
    return jsonify(result)


@app.errorhandler(413)
def too_large(_):
    return error_response(f"File too large. Maximum size is {config.MAX_UPLOAD_MB} MB.", 413)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
