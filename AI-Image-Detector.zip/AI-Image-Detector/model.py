"""
model.py - the neural network.
Main model: ResNet-50 (pretrained on ImageNet) + custom head from the paper:
  ResNet-50 -> Global Average Pooling -> 2048 -> Linear(2048,512) -> ReLU -> Dropout(0.5) -> Linear(512,1) -> Sigmoid

NOTE: the network outputs a raw number (a "logit"). Sigmoid is applied when we need a
probability. Training uses BCEWithLogitsLoss = Sigmoid + Binary Cross-Entropy in one
numerically-stable step, mathematically the same as the paper's loss.
"""
import os
import torch
import torch.nn as nn
from torchvision import models

import config


class AIImageDetector(nn.Module):
    def __init__(self, pretrained=True):
        super().__init__()
        weights = models.ResNet50_Weights.IMAGENET1K_V1 if pretrained else None   # downloads ~100 MB once
        backbone = models.resnet50(weights=weights)
        backbone.fc = nn.Identity()          # remove the 1000-class ImageNet layer (global avg-pool is kept)
        self.backbone = backbone             # outputs 2048 features per image
        self.head = nn.Sequential(           # custom classification head
            nn.Linear(2048, 512),
            nn.ReLU(),
            nn.Dropout(config.DROPOUT),
            nn.Linear(512, 1),
        )

    def forward(self, x):
        return self.head(self.backbone(x)).squeeze(1)      # shape: (batch,) logits


# ---------------------------------------------------- two-stage transfer learning
def freeze_backbone(model):
    """Stage 1: freeze the whole ResNet-50; only the head learns."""
    for p in model.backbone.parameters():
        p.requires_grad = False


def unfreeze_last_block(model):
    """Stage 2: unfreeze ONLY layer4 (the final residual block) for fine-tuning."""
    for p in model.backbone.layer4.parameters():
        p.requires_grad = True


def set_train_mode(model, stage):
    """Frozen parts stay in eval() mode so their BatchNorm statistics are not changed."""
    model.train()
    if stage == 1:
        model.backbone.eval()
    else:
        for name, module in model.backbone.named_children():
            if name != "layer4":
                module.eval()


# ------------------------------------------------------------- save / load
def save_checkpoint(model, path=None):
    os.makedirs(config.MODELS_DIR, exist_ok=True)
    torch.save({
        "model_state": model.state_dict(),
        "class_names": config.CLASS_NAMES,
        "image_size": config.IMAGE_SIZE,
        "mean": config.IMAGENET_MEAN,
        "std": config.IMAGENET_STD,
        "threshold": config.THRESHOLD,
        "architecture": "resnet50",
    }, path or config.MODEL_PATH)


def load_trained_model(device, path=None):
    path = path or config.MODEL_PATH
    if not os.path.exists(path):
        raise FileNotFoundError(
            "Trained model not found at models/resnet50_ai_detector.pth. "
            "Run train.py first (or copy the .pth file downloaded from Colab into the models folder)."
        )
    checkpoint = torch.load(path, map_location=device, weights_only=True)
    model = AIImageDetector(pretrained=False)          # no need to download ImageNet weights again
    model.load_state_dict(checkpoint["model_state"])
    model.to(device).eval()
    return model


# ------------------------------------------------ OPTIONAL comparison models
def build_comparison_model(name):
    """OPTIONAL (used only by compare_models.py). Returns (model, new_output_layer, pretrained?)."""
    if name == "baseline_cnn":       # simple 3-layer CNN trained from scratch
        layers = nn.Sequential(
            nn.Conv2d(3, 32, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(64, 128, 3, padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.AdaptiveAvgPool2d(1), nn.Flatten())
        out = nn.Linear(128, 1)
        return nn.Sequential(layers, out, nn.Flatten(0)), out, False
    if name == "vgg16":
        net = models.vgg16(weights=models.VGG16_Weights.IMAGENET1K_V1)
        net.classifier[6] = nn.Linear(4096, 1)
        return nn.Sequential(net, nn.Flatten(0)), net.classifier[6], True
    if name == "efficientnet_b0":
        net = models.efficientnet_b0(weights=models.EfficientNet_B0_Weights.IMAGENET1K_V1)
        net.classifier[1] = nn.Linear(1280, 1)
        return nn.Sequential(net, nn.Flatten(0)), net.classifier[1], True
    if name == "vit_b_16":
        net = models.vit_b_16(weights=models.ViT_B_16_Weights.IMAGENET1K_V1)
        net.heads.head = nn.Linear(768, 1)
        return nn.Sequential(net, nn.Flatten(0)), net.heads.head, True
    raise ValueError(f"Unknown model: {name}")
