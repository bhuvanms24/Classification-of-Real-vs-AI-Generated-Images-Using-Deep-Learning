// script.js - handles choosing an image, showing a preview, calling the Flask
// back end (/predict) and displaying the result.

const dropzone = document.getElementById("dropzone");
const fileInput = document.getElementById("fileInput");
const previewBox = document.getElementById("previewBox");
const previewImage = document.getElementById("previewImage");
const fileMeta = document.getElementById("fileMeta");
const analyzeBtn = document.getElementById("analyzeBtn");
const resetBtn = document.getElementById("resetBtn");
const loading = document.getElementById("loading");
const resultBox = document.getElementById("result");
const errorBox = document.getElementById("errorMessage");

const ALLOWED = ["jpg", "jpeg", "png", "webp", "bmp"];
let selectedFile = null;

function showError(message) { errorBox.textContent = message; errorBox.hidden = false; }
function clearError() { errorBox.hidden = true; errorBox.textContent = ""; }

function chooseFile(file) {
  clearError();
  resultBox.hidden = true;
  if (!file) return;
  const ext = file.name.split(".").pop().toLowerCase();
  if (!ALLOWED.includes(ext)) {
    showError("Unsupported file type. Please choose a JPG, PNG, WEBP or BMP image.");
    return;
  }
  selectedFile = file;
  previewImage.src = URL.createObjectURL(file);
  fileMeta.textContent = file.name + " (" + (file.size / 1024).toFixed(0) + " KB)";
  previewBox.hidden = false;
  analyzeBtn.disabled = false;
  resetBtn.hidden = false;
}

// click / keyboard / drag-and-drop
dropzone.addEventListener("click", () => fileInput.click());
dropzone.addEventListener("keydown", (e) => {
  if (e.key === "Enter" || e.key === " ") { e.preventDefault(); fileInput.click(); }
});
fileInput.addEventListener("change", () => chooseFile(fileInput.files[0]));
["dragenter", "dragover"].forEach((ev) =>
  dropzone.addEventListener(ev, (e) => { e.preventDefault(); dropzone.classList.add("dragging"); }));
["dragleave", "drop"].forEach((ev) =>
  dropzone.addEventListener(ev, (e) => { e.preventDefault(); dropzone.classList.remove("dragging"); }));
dropzone.addEventListener("drop", (e) => chooseFile(e.dataTransfer.files[0]));

analyzeBtn.addEventListener("click", async () => {
  if (!selectedFile) { showError("No image uploaded. Please choose an image first."); return; }
  clearError();
  resultBox.hidden = true;
  analyzeBtn.disabled = true;
  loading.hidden = false;

  const formData = new FormData();
  formData.append("image", selectedFile);

  try {
    const response = await fetch("/predict", { method: "POST", body: formData });
    const data = await response.json();
    if (!response.ok || !data.success) {
      showError(data.error || "Something went wrong. Please try again.");
    } else {
      showResult(data);
    }
  } catch (err) {
    showError("Cannot reach the server. Make sure 'python app.py' is still running.");
  } finally {
    loading.hidden = true;
    analyzeBtn.disabled = false;
  }
});

function showResult(data) {
  resultBox.className = "result " + (data.is_real ? "is-real" : "is-ai");
  document.getElementById("resultLabel").textContent = data.label;
  document.getElementById("resultConfidence").textContent = data.confidence.toFixed(2) + "%";
  document.getElementById("resultDetails").textContent =
    "Real: " + data.prob_real.toFixed(2) + "%  |  AI-generated: " + data.prob_ai.toFixed(2) + "%  |  " +
    data.width + " × " + data.height + " px, " + data.format;
  resultBox.hidden = false;
  const bar = document.getElementById("confidenceBar");
  bar.style.width = "0";
  requestAnimationFrame(() => { bar.style.width = data.confidence.toFixed(2) + "%"; });
}

resetBtn.addEventListener("click", () => {
  selectedFile = null;
  fileInput.value = "";
  previewBox.hidden = true;
  previewImage.removeAttribute("src");
  resultBox.hidden = true;
  analyzeBtn.disabled = true;
  resetBtn.hidden = true;
  clearError();
});
