"""
train.py - trains the ResNet-50 detector (two-stage transfer learning).

Run (VS Code terminal, virtual environment active):
    python train.py
Quick test on a tiny sample / slow PC:
    python train.py --limit-per-class 200 --max-epochs 6 --stage1-epochs 2
"""
import os
import json
import argparse
import torch
import torch.nn as nn

import config
import data_utils
from model import (AIImageDetector, freeze_backbone, unfreeze_last_block,
                   set_train_mode, save_checkpoint)


def train_one_epoch(model, loader, criterion, optimizer, device):
    total_loss, correct, count = 0.0, 0, 0
    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()
        logits = model(images)
        loss = criterion(logits, labels)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * images.size(0)
        correct += ((logits > 0).float() == labels).sum().item()   # logit > 0  <=>  probability > 0.5
        count += images.size(0)
    return total_loss / count, correct / count


@torch.no_grad()
def validate(model, loader, criterion, device):
    model.eval()
    total_loss, correct, count = 0.0, 0, 0
    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        logits = model(images)
        total_loss += criterion(logits, labels).item() * images.size(0)
        correct += ((logits > 0).float() == labels).sum().item()
        count += images.size(0)
    return total_loss / count, correct / count


def fit_stage(model, loaders, optimizer, scheduler, criterion, device, num_epochs,
              history, best, train_mode_fn, stage_name, use_early_stopping, patience, save_fn):
    """Train for up to num_epochs. Saves the model whenever validation loss improves."""
    train_loader, val_loader = loaders
    epochs_without_improvement = 0
    for _ in range(num_epochs):
        train_mode_fn(model)
        train_loss, train_acc = train_one_epoch(model, train_loader, criterion, optimizer, device)
        val_loss, val_acc = validate(model, val_loader, criterion, device)
        if scheduler is not None:
            scheduler.step(val_loss)

        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["train_acc"].append(train_acc)
        history["val_acc"].append(val_acc)
        epoch_no = len(history["train_loss"])
        lr_now = optimizer.param_groups[0]["lr"]

        improved = val_loss < best["val_loss"]
        if improved:
            best["val_loss"], best["epoch"] = val_loss, epoch_no
            save_fn()
            epochs_without_improvement = 0
        else:
            epochs_without_improvement += 1
        print(f"[{stage_name}] epoch {epoch_no:2d} | train loss {train_loss:.4f} acc {train_acc:.4f} | "
              f"val loss {val_loss:.4f} acc {val_acc:.4f} | lr {lr_now:.1e}" + ("  <- best, saved" if improved else ""))

        if use_early_stopping and epochs_without_improvement >= patience:
            print(f"Early stopping: no improvement for {patience} epochs.")
            break


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-epochs", type=int, default=config.MAX_EPOCHS)
    parser.add_argument("--stage1-epochs", type=int, default=config.STAGE1_EPOCHS)
    parser.add_argument("--batch-size", type=int, default=config.BATCH_SIZE)
    parser.add_argument("--limit-per-class", type=int, default=None,
                        help="use only N images per class (for quick tests)")
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")
    if device.type == "cpu":
        print("(No GPU found - training on CPU works but is slow. Consider Google Colab.)")

    try:
        splits = data_utils.prepare_splits(args.limit_per_class)
    except data_utils.DatasetError as error:
        print(f"\nDATASET PROBLEM:\n{error}")
        return

    train_loader = data_utils.make_loader(splits["train"], train=True, batch_size=args.batch_size)
    val_loader = data_utils.make_loader(splits["val"], train=False, batch_size=args.batch_size)

    print("\nLoading ResNet-50 with ImageNet weights (first run downloads ~100 MB, needs internet)...")
    model = AIImageDetector(pretrained=True).to(device)
    criterion = nn.BCEWithLogitsLoss()
    history = {"train_loss": [], "val_loss": [], "train_acc": [], "val_acc": []}
    best = {"val_loss": float("inf"), "epoch": 0}
    save_fn = lambda: save_checkpoint(model)

    # ---------------- Stage 1: freeze backbone, train the head only ----------------
    print("\n=== STAGE 1: backbone frozen, training classification head (lr 1e-4) ===")
    freeze_backbone(model)
    optimizer = torch.optim.Adam(model.head.parameters(), lr=config.LR_HEAD)
    fit_stage(model, (train_loader, val_loader), optimizer, None, criterion, device,
              args.stage1_epochs, history, best, lambda m: set_train_mode(m, 1),
              "stage 1", False, config.EARLY_STOP_PATIENCE, save_fn)

    # ---------------- Stage 2: unfreeze final residual block (layer4) ----------------
    print("\n=== STAGE 2: fine-tuning layer4 (lr 1e-5) + head (lr 1e-4) ===")
    unfreeze_last_block(model)
    optimizer = torch.optim.Adam([
        {"params": model.head.parameters(), "lr": config.LR_HEAD},
        {"params": model.backbone.layer4.parameters(), "lr": config.LR_FINETUNE},
    ])
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="min", factor=config.SCHEDULER_FACTOR, patience=config.SCHEDULER_PATIENCE)
    fit_stage(model, (train_loader, val_loader), optimizer, scheduler, criterion, device,
              max(args.max_epochs - args.stage1_epochs, 0), history, best,
              lambda m: set_train_mode(m, 2), "stage 2", True, config.EARLY_STOP_PATIENCE, save_fn)

    # ---------------- Save history + graphs ----------------
    os.makedirs(config.RESULTS_DIR, exist_ok=True)
    with open(config.HISTORY_PATH, "w") as f:
        json.dump(history, f, indent=2)
    from evaluate import plot_history           # imported here to keep start-up fast
    plot_history(history)

    print(f"\nTraining finished. Best epoch: {best['epoch']} (val loss {best['val_loss']:.4f})")
    print(f"Best model saved to: {config.MODEL_PATH}")
    print("Next step: python evaluate.py")


if __name__ == "__main__":
    main()
